$("#loginForm").submit(function(e){
e.preventDefault();
if($("#user").val()=="admin" && $("#password").val()=="1234"){
window.location.href="menu.html";
}else{
alert("Usuario o contraseña incorrectos");
}
});